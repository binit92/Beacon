Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents BinPackingGraph1 As Bin_Packing_Graph.BinPackingGraph
   Friend WithEvents BinPackingGraph2 As Bin_Packing_Graph.BinPackingGraph
   Friend WithEvents txtElements As System.Windows.Forms.TextBox
   Friend WithEvents nudBinHeight As System.Windows.Forms.NumericUpDown
   Friend WithEvents lblBinHeight As System.Windows.Forms.Label
   Friend WithEvents cbDecreasing As System.Windows.Forms.CheckBox
   Friend WithEvents lblElements As System.Windows.Forms.Label
   Friend WithEvents cbBinPackingAlgorithm As System.Windows.Forms.ComboBox
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.BinPackingGraph2 = New Bin_Packing_Graph.BinPackingGraph
      Me.txtElements = New System.Windows.Forms.TextBox
      Me.nudBinHeight = New System.Windows.Forms.NumericUpDown
      Me.lblBinHeight = New System.Windows.Forms.Label
      Me.cbDecreasing = New System.Windows.Forms.CheckBox
      Me.lblElements = New System.Windows.Forms.Label
      Me.cbBinPackingAlgorithm = New System.Windows.Forms.ComboBox
      CType(Me.nudBinHeight, System.ComponentModel.ISupportInitialize).BeginInit()
      Me.SuspendLayout()
      '
      'BinPackingGraph2
      '
      Me.BinPackingGraph2.Algorithm = Bin_Packing_Graph.BinPackingGraph.BinPackingAlgorithm.NextFit
      Me.BinPackingGraph2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                  Or System.Windows.Forms.AnchorStyles.Left) _
                  Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
      Me.BinPackingGraph2.AutoUpdate = False
      Me.BinPackingGraph2.BinColor1 = System.Drawing.Color.FromArgb(CType(255, Byte), CType(222, Byte), CType(173, Byte))
      Me.BinPackingGraph2.BinColor2 = System.Drawing.Color.FromArgb(CType(255, Byte), CType(140, Byte), CType(0, Byte))
      Me.BinPackingGraph2.BinHeight = 80
      Me.BinPackingGraph2.BinTextColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
      Me.BinPackingGraph2.Decreasing = False
      Me.BinPackingGraph2.Elements = Nothing
      Me.BinPackingGraph2.Location = New System.Drawing.Point(5, 5)
      Me.BinPackingGraph2.Name = "BinPackingGraph2"
      Me.BinPackingGraph2.Size = New System.Drawing.Size(837, 402)
      Me.BinPackingGraph2.TabIndex = 0
      '
      'txtElements
      '
      Me.txtElements.Anchor = System.Windows.Forms.AnchorStyles.Right
      Me.txtElements.Location = New System.Drawing.Point(856, 73)
      Me.txtElements.Multiline = True
      Me.txtElements.Name = "txtElements"
      Me.txtElements.Size = New System.Drawing.Size(200, 200)
      Me.txtElements.TabIndex = 1
      Me.txtElements.Text = "26 57 18 8 45 16 22 29 5 11 8 27 54 13 17 21 63 14 16 45 6 32 57 24 18 27 54 35 1" & _
      "2 43 36 72 14 28 3 11 46 27 42 59 26 41 15 41 68"
      '
      'nudBinHeight
      '
      Me.nudBinHeight.Anchor = System.Windows.Forms.AnchorStyles.Right
      Me.nudBinHeight.Location = New System.Drawing.Point(856, 301)
      Me.nudBinHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
      Me.nudBinHeight.Name = "nudBinHeight"
      Me.nudBinHeight.Size = New System.Drawing.Size(69, 20)
      Me.nudBinHeight.TabIndex = 3
      Me.nudBinHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
      Me.nudBinHeight.Value = New Decimal(New Integer() {80, 0, 0, 0})
      '
      'lblBinHeight
      '
      Me.lblBinHeight.Anchor = System.Windows.Forms.AnchorStyles.Right
      Me.lblBinHeight.AutoSize = True
      Me.lblBinHeight.Location = New System.Drawing.Point(862, 285)
      Me.lblBinHeight.Name = "lblBinHeight"
      Me.lblBinHeight.Size = New System.Drawing.Size(56, 16)
      Me.lblBinHeight.TabIndex = 4
      Me.lblBinHeight.Text = "Bin Height"
      '
      'cbDecreasing
      '
      Me.cbDecreasing.Anchor = System.Windows.Forms.AnchorStyles.Right
      Me.cbDecreasing.Location = New System.Drawing.Point(973, 299)
      Me.cbDecreasing.Name = "cbDecreasing"
      Me.cbDecreasing.Size = New System.Drawing.Size(83, 24)
      Me.cbDecreasing.TabIndex = 0
      Me.cbDecreasing.Text = "Decreasing"
      '
      'lblElements
      '
      Me.lblElements.Anchor = System.Windows.Forms.AnchorStyles.Right
      Me.lblElements.AutoSize = True
      Me.lblElements.Location = New System.Drawing.Point(931, 57)
      Me.lblElements.Name = "lblElements"
      Me.lblElements.Size = New System.Drawing.Size(51, 16)
      Me.lblElements.TabIndex = 6
      Me.lblElements.Text = "Elements"
      '
      'cbBinPackingAlgorithm
      '
      Me.cbBinPackingAlgorithm.Anchor = System.Windows.Forms.AnchorStyles.Right
      Me.cbBinPackingAlgorithm.Items.AddRange(New Object() {"Next Fit", "First Fit", "Best Fit", "Worst Fit"})
      Me.cbBinPackingAlgorithm.Location = New System.Drawing.Point(916, 331)
      Me.cbBinPackingAlgorithm.Name = "cbBinPackingAlgorithm"
      Me.cbBinPackingAlgorithm.Size = New System.Drawing.Size(80, 21)
      Me.cbBinPackingAlgorithm.TabIndex = 7
      Me.cbBinPackingAlgorithm.Text = "Next Fit"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.BackColor = System.Drawing.Color.White
      Me.ClientSize = New System.Drawing.Size(1075, 425)
      Me.Controls.Add(Me.cbBinPackingAlgorithm)
      Me.Controls.Add(Me.lblElements)
      Me.Controls.Add(Me.cbDecreasing)
      Me.Controls.Add(Me.lblBinHeight)
      Me.Controls.Add(Me.nudBinHeight)
      Me.Controls.Add(Me.txtElements)
      Me.Controls.Add(Me.BinPackingGraph2)
      Me.Name = "Form1"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
      Me.Text = "Bin Packing"
      CType(Me.nudBinHeight, System.ComponentModel.ISupportInitialize).EndInit()
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private bLoaded As Boolean = False

   Private Sub Calculate()
      If bLoaded = False Then Exit Sub

      BinPackingGraph2.BinHeight = CType(nudBinHeight.Value, Integer)
      BinPackingGraph2.Decreasing = cbDecreasing.Checked
      BinPackingGraph2.Algorithm = CType(cbBinPackingAlgorithm.SelectedIndex, Bin_Packing_Graph.BinPackingGraph.BinPackingAlgorithm)

      Dim strElements() As String = txtElements.Text.Split(" "c)
      Dim intElements(strElements.GetUpperBound(0)) As Integer
      Dim bSuccess As Boolean = True
      Dim i As Integer

      For i = 0 To strElements.GetUpperBound(0)
         If IsNumeric(strElements(i)) Then
            intElements(i) = CType(strElements(i), Integer)
         Else
            bSuccess = False
         End If
      Next

      If bSuccess Then
         BinPackingGraph2.Elements = intElements
         BinPackingGraph2.Compute()
      End If
   End Sub

   Private Sub cbDecreasing_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbDecreasing.CheckedChanged
      Calculate()
   End Sub

   Private Sub nudBinHeight_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nudBinHeight.ValueChanged
      Calculate()
   End Sub

   Private Sub txtElements_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtElements.TextChanged
      Calculate()
   End Sub

   Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      bLoaded = True
      Calculate()
   End Sub

   Private Sub cbBinPackingAlgorithm_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbBinPackingAlgorithm.SelectedIndexChanged
      Calculate()
   End Sub
End Class
